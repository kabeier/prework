# Question 1
def hello_name(user_name):
    """prints string Hello_ with the defined string username appended"""
    print("Hello_"+user_name)

# Question 2   (enclosed in a function even though is says just to print)
def print_firstodd():
    """prints the odd numbers between 1 and 100"""
    number=1
    odds=0
    while(odds<=100):
        if(number%2 != 0):
            print(number)
            odds+=1
        number+=1
            

# Question 3 (without the max() function )
def max_num_in_list(a_list):
    """takes a list of numbers and returns the number of the maximum value"""
    maxnum=0
    for number in a_list:
        if number > maxnum:
            maxnum=number
    return maxnum

# Questions 4
def is_leap_year(a_year):
    """takes in a int for a year and returns TRUE if the year is a leap year"""
    if (a_year % 4 == 0 and a_year % 100 != 0) or\
           (a_year % 4 == 0 and a_year % 100 == 0 and a_year % 400 == 0):
        return True
    else:
        return False

# Question 5
def is_consecutive(a_list):
    """takes a int list and returns TRUE if the numbers are consecutive and in consective order./
          Throws error if not a list or not integers (just for fun)"""
    if(not type(a_list) is list):raise InputError("Must be a list not even a tuple!")
    for x in a_list:
        if(not type(x) is int):raise InputError("I TOLD YOU INTEGERS ONLY!") 
    end=len(a_list)
    if end < 2:
        return False

    for number in range(0,end-1):
        if a_list[number] + 1 == a_list[number + 1]:
            continue
        else:
            return False
    return True

class InputError(Exception):
    """Exception raised for errors in the input."""

    def __init__(self, message):
            self.message = message



